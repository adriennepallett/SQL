SELECT Course_No, Course_Name
FROM Courses
WHERE PreReq = 'MATH1040'
ORDER BY 'Course_Type';